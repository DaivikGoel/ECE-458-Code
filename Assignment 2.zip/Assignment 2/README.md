# ECE 458 assignment 2 Code

```pip3 install sympy```

```python3 assignment2.py```

uncomment any print statements that might be necessary

Select question to be run (1-5) 

for example:
> WHICH QUESTION DO YOU WANT: 5


In question 2, the user is expected to input an integer to calculate the SHA3-224 value of their input.